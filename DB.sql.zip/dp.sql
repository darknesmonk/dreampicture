-- phpMyAdmin SQL Dump
-- version 3.5.1
-- http://www.phpmyadmin.net
--
-- Хост: 127.0.0.1
-- Время создания: Сен 03 2015 г., 19:00
-- Версия сервера: 5.5.25
-- Версия PHP: 5.3.13

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- База данных: `dp`
--

-- --------------------------------------------------------

--
-- Структура таблицы `banlist`
--

CREATE TABLE IF NOT EXISTS `banlist` (
  `id` mediumint(9) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `time` time DEFAULT NULL,
  `ip` varchar(16) DEFAULT NULL,
  `text` text,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ip` (`ip`)
) ENGINE=MyISAM DEFAULT CHARSET=cp1251 COMMENT='Список заблокированных IP-адресов' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `bots`
--

CREATE TABLE IF NOT EXISTS `bots` (
  `bid` mediumint(9) NOT NULL AUTO_INCREMENT,
  `bname` tinytext,
  `buagent` tinytext,
  `blogo` varchar(50) DEFAULT 'none.gif',
  `blastagent` tinytext,
  `bdatetime` datetime DEFAULT NULL,
  `blastpage` varchar(100) DEFAULT '/',
  `blastrefer` varchar(255) DEFAULT '/',
  `bcount` mediumint(9) DEFAULT '0',
  `bip` varchar(40) DEFAULT '127.0.0.1',
  PRIMARY KEY (`bid`),
  KEY `bip` (`bip`)
) ENGINE=MyISAM DEFAULT CHARSET=cp1251 COMMENT='Визиты поисковых ботов' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `category`
--

CREATE TABLE IF NOT EXISTS `category` (
  `catid` mediumint(9) NOT NULL AUTO_INCREMENT,
  `catref` datetime DEFAULT NULL,
  `catname` tinytext,
  `catdes` tinytext,
  `catkeywords` tinytext,
  `thumbs` varchar(20) DEFAULT NULL,
  `catfotos` mediumint(9) DEFAULT '0',
  PRIMARY KEY (`catid`),
  KEY `thumbs` (`thumbs`)
) ENGINE=MyISAM  DEFAULT CHARSET=cp1251 COMMENT='Категории' AUTO_INCREMENT=2 ;

--
-- Дамп данных таблицы `category`
--

INSERT INTO `category` (`catid`, `catref`, `catname`, `catdes`, `catkeywords`, `thumbs`, `catfotos`) VALUES
(1, '2015-09-03 17:59:07', 'Тест', 'тестовый каталог', 'тест, проба, рисунки, фигня', '12|10|12|7', 12);

-- --------------------------------------------------------

--
-- Структура таблицы `ffolders`
--

CREATE TABLE IF NOT EXISTS `ffolders` (
  `ffid` mediumint(9) NOT NULL AUTO_INCREMENT,
  `mainfolder` varchar(35) DEFAULT 'dreamfolder6692_y79_03092015',
  `ffolder` varchar(20) DEFAULT 'v139_031503095906',
  `files` smallint(6) DEFAULT '0',
  `kbsize` mediumint(9) DEFAULT '0',
  `blocked` enum('0','1') DEFAULT '0',
  PRIMARY KEY (`ffid`),
  KEY `files` (`files`),
  KEY `mainfolder` (`mainfolder`),
  KEY `kbsize` (`kbsize`)
) ENGINE=MyISAM  DEFAULT CHARSET=cp1251 COMMENT='Фото-папки' AUTO_INCREMENT=13 ;

--
-- Дамп данных таблицы `ffolders`
--

INSERT INTO `ffolders` (`ffid`, `mainfolder`, `ffolder`, `files`, `kbsize`, `blocked`) VALUES
(1, 'dreamfolder9712_t24_03092015', 'u870_231503095806', 3, 582, '0'),
(2, 'dreamfolder7946_v32_03092015', 'm786_271503095806', 3, 409, '0'),
(3, 'dreamfolder6327_f23_03092015', 'e776_311503095806', 3, 849, '0'),
(4, 'dreamfolder9662_f64_03092015', 'z265_351503095806', 3, 395, '0'),
(5, 'dreamfolder5157_d26_03092015', 't840_381503095806', 3, 416, '0'),
(6, 'dreamfolder5732_d31_03092015', 'a594_421503095806', 3, 582, '0'),
(7, 'dreamfolder5684_r21_03092015', 'a843_461503095806', 3, 337, '0'),
(8, 'dreamfolder7196_t96_03092015', 't706_491503095806', 3, 339, '0'),
(9, 'dreamfolder7492_n82_03092015', 'c817_531503095806', 3, 298, '0'),
(10, 'dreamfolder9523_f28_03092015', 'z887_571503095806', 3, 177, '0'),
(11, 'dreamfolder8314_d93_03092015', 'm983_001503095906', 3, 515, '0'),
(12, 'dreamfolder6692_y79_03092015', 'v139_031503095906', 3, 420, '0');

-- --------------------------------------------------------

--
-- Структура таблицы `fotos`
--

CREATE TABLE IF NOT EXISTS `fotos` (
  `fid` mediumint(9) NOT NULL AUTO_INCREMENT,
  `fdatetime` datetime DEFAULT NULL,
  `folderid` mediumint(9) DEFAULT '1',
  `fname` tinytext,
  `full` varchar(100) DEFAULT NULL,
  `thumb` varchar(100) DEFAULT NULL,
  `gray` varchar(100) DEFAULT NULL,
  `fsizekb` int(5) DEFAULT NULL,
  `ip` varchar(16) DEFAULT '127.0.0.1',
  `subcategory` mediumint(9) DEFAULT '1',
  `transurl` tinytext,
  `width_px` smallint(4) DEFAULT '0',
  `height_px` smallint(4) DEFAULT '0',
  `color_r` smallint(6) DEFAULT '0',
  `color_g` smallint(6) DEFAULT '0',
  `color_b` smallint(6) DEFAULT '0',
  PRIMARY KEY (`fid`),
  KEY `folderid` (`folderid`),
  KEY `subcategory` (`subcategory`),
  KEY `width_px` (`width_px`),
  KEY `height_px` (`height_px`),
  KEY `color_r` (`color_r`),
  KEY `color_g` (`color_g`),
  KEY `color_b` (`color_b`),
  KEY `fdatetime` (`fdatetime`)
) ENGINE=MyISAM  DEFAULT CHARSET=cp1251 COMMENT='Фотографии' AUTO_INCREMENT=13 ;

--
-- Дамп данных таблицы `fotos`
--

INSERT INTO `fotos` (`fid`, `fdatetime`, `folderid`, `fname`, `full`, `thumb`, `gray`, `fsizekb`, `ip`, `subcategory`, `transurl`, `width_px`, `height_px`, `color_r`, `color_g`, `color_b`) VALUES
(1, '2015-09-03 17:58:26', 1, '113649595', 'e_6707031809152358.jpg', 'e_6707031809152358_thumb.jpg', 'e_6707031809152358_gray.jpg', 327, '127.0.0.1', 1, '113649595', 1600, 1200, 139, 175, 171),
(2, '2015-09-03 17:58:30', 2, '367483658', 't_7258031809152758.jpg', 't_7258031809152758_thumb.jpg', 't_7258031809152758_gray.jpg', 242, '127.0.0.1', 1, '367483658', 1600, 1200, 200, 130, 120),
(3, '2015-09-03 17:58:34', 3, 'w_24bd015d', 'v_8465031809153158.jpg', 'v_8465031809153158_thumb.jpg', 'v_8465031809153158_gray.jpg', 502, '127.0.0.1', 1, 'w_24bd015d', 1600, 1200, 231, 219, 161),
(4, '2015-09-03 17:58:37', 4, '780564966', 'v_5932031809153558.jpg', 'v_5932031809153558_thumb.jpg', 'v_5932031809153558_gray.jpg', 229, '127.0.0.1', 1, '780564966', 1280, 960, 247, 196, 105),
(5, '2015-09-03 17:58:41', 5, '394844-1-f', 'f_9906031809153858.jpg', 'f_9906031809153858_thumb.jpg', 'f_9906031809153858_gray.jpg', 231, '127.0.0.1', 1, '394844-1-f', 1600, 1200, 197, 231, 232),
(6, '2015-09-03 17:58:45', 6, '200410183425814785', 'b_2505031809154258.jpg', 'b_2505031809154258_thumb.jpg', 'b_2505031809154258_gray.jpg', 315, '127.0.0.1', 1, '200410183425814785', 1159, 1644, 164, 56, 18),
(7, '2015-09-03 17:58:49', 7, '228512685', 'f_9029031809154658.jpg', 'f_9029031809154658_thumb.jpg', 'f_9029031809154658_gray.jpg', 185, '127.0.0.1', 1, '228512685', 1280, 1024, 187, 178, 173),
(8, '2015-09-03 17:58:53', 8, 'z_c19545f5', 'c_4632031809154958.jpg', 'c_4632031809154958_thumb.jpg', 'c_4632031809154958_gray.jpg', 194, '127.0.0.1', 1, 'z_c19545f5', 2000, 1125, 147, 44, 65),
(9, '2015-09-03 17:58:56', 9, '1259076636_266447_2', 'm_7056031809155358.jpg', 'm_7056031809155358_thumb.jpg', 'm_7056031809155358_gray.jpg', 173, '127.0.0.1', 1, '1259076636_266447_2', 1280, 1024, 243, 236, 217),
(10, '2015-09-03 17:58:59', 10, '54133-Nika', 'a_8029031809155758.jpg', 'a_8029031809155758_thumb.jpg', 'a_8029031809155758_gray.jpg', 97, '127.0.0.1', 1, '54133-nika', 1024, 768, 255, 90, 96),
(11, '2015-09-03 17:59:03', 11, '690975378', 'm_4118031809150059.jpg', 'm_4118031809150059_thumb.jpg', 'm_4118031809150059_gray.jpg', 289, '127.0.0.1', 1, '690975378', 1280, 1024, 69, 63, 89),
(12, '2015-09-03 17:59:07', 12, 'anime-wallpaper-1920x1200-013', 'm_6469031809150359.jpg', 'm_6469031809150359_thumb.jpg', 'm_6469031809150359_gray.jpg', 241, '127.0.0.1', 1, 'anime-wallpaper-1920x1200-013', 1920, 1200, 254, 254, 254);

-- --------------------------------------------------------

--
-- Структура таблицы `oldurls`
--

CREATE TABLE IF NOT EXISTS `oldurls` (
  `uid` mediumint(9) NOT NULL AUTO_INCREMENT,
  `uname` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `uname` (`uname`)
) ENGINE=MyISAM DEFAULT CHARSET=cp1251 COMMENT='Перевод старых ссылок' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `params`
--

CREATE TABLE IF NOT EXISTS `params` (
  `pid` mediumint(9) NOT NULL AUTO_INCREMENT,
  `dpadminpass` varchar(32) DEFAULT NULL,
  `maxonepage` tinyint(4) DEFAULT NULL,
  `FULLPATH` varchar(20) DEFAULT NULL,
  `THUMBPATH` varchar(20) DEFAULT NULL,
  `GREYPATH` varchar(20) DEFAULT NULL,
  `PAGESPATH` varchar(20) DEFAULT NULL,
  `mlkb` mediumint(9) DEFAULT NULL,
  `mlf` mediumint(9) DEFAULT NULL,
  `ff` mediumint(9) DEFAULT NULL,
  `curtempl` varchar(50) DEFAULT NULL,
  `fotodir` varchar(50) DEFAULT NULL,
  `description` text NOT NULL,
  `keywords` text NOT NULL,
  PRIMARY KEY (`pid`)
) ENGINE=MyISAM  DEFAULT CHARSET=cp1251 COMMENT='Настройки' AUTO_INCREMENT=2 ;

--
-- Дамп данных таблицы `params`
--

INSERT INTO `params` (`pid`, `dpadminpass`, `maxonepage`, `FULLPATH`, `THUMBPATH`, `GREYPATH`, `PAGESPATH`, `mlkb`, `mlf`, `ff`, `curtempl`, `fotodir`, `description`, `keywords`) VALUES
(1, '81dc9bdb52d04dc20036dbd8313ed055', 54, '/public/full/', '/public/thumb/', '/public/gray/', '/pages/', 51200, 180, 50, 'classic', 'fotos/', 'Коллекция самых красивых, качественных и насыщенных рисунков для Вас в высоком разрешении', 'рисунки, фото, картинки, галерея, залить, без рекламы, удобно, картинка на сайт, альбомы, бесплатно, быстро, удобно, обои, на блог, на форум, в дневник, развлечения. природа, аниме, авто, фотографии, красиво, пейзажи');

-- --------------------------------------------------------

--
-- Структура таблицы `smiles`
--

CREATE TABLE IF NOT EXISTS `smiles` (
  `id` mediumint(9) NOT NULL AUTO_INCREMENT,
  `code` varchar(30) DEFAULT NULL,
  `des` tinytext,
  `src` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`)
) ENGINE=MyISAM  DEFAULT CHARSET=cp1251 COMMENT='Смайлы' AUTO_INCREMENT=123 ;

--
-- Дамп данных таблицы `smiles`
--

INSERT INTO `smiles` (`id`, `code`, `des`, `src`) VALUES
(30, ':vampir:', 'Я вампир, пью кровь!', 'ea'),
(29, ':isterik:', 'Я истиричка!', 'cm'),
(28, ':gun:', 'Стреляю', 'cl'),
(27, ':fingal:', 'Фингал', 'cg'),
(26, ':boss:', 'Босс', 'bz'),
(25, ':cool:', 'Круто', 'by'),
(24, ':bum:', 'Убъюсь', 'bu'),
(23, ':hello:', 'Привет', 'bq'),
(22, ':sorry:', 'Извините', 'bh'),
(21, ':yoo:', 'Крутой', 'bd'),
(20, ':sos:', 'Помогите', 'bc'),
(19, ':music:', 'Музыка', 'ar'),
(18, ':yahoo:', 'Ура!', 'yahoo000'),
(17, ';)', 'Подмигнул', 'wink0000'),
(16, ':vic:', 'Победа', 'victory0'),
(15, ':-0', 'Испугался', 'scare000'),
(14, ':sleep:', 'Сплю', 'lazy2000'),
(13, 'xD', 'Хаха', 'haha0000'),
(12, ':friends:', 'Друзья', 'friends0'),
(11, ':-!', 'Дурак', 'fool0000'),
(10, ':x', 'Гадость', 'bad00000'),
(9, '0;-)', 'Ангел', 'angel000'),
(8, ':--((', 'Плачу', 'cray0000'),
(7, ']:-(', 'Злой', 'aggressi'),
(6, '[::]', 'Правила', 'icon_off'),
(5, '^_^', 'Смущаюсь', 'icon_red'),
(4, ':D', 'Весело', 'biggrin'),
(3, '8)', 'Очки', 'icon_coo'),
(2, ':(', 'Печаль', 'icon_sad'),
(1, ':)', 'Смайлик', 'icon_smi'),
(31, ':em:', 'Хорошо-то как...', 'dw'),
(32, ':zloy:', 'Не злите!', 'dx'),
(33, ':4u4ka:', 'Чушка', 'bg'),
(34, ':bravo:', 'Браво!', 'bi'),
(35, ':crazy:', 'Псих', 'bm'),
(36, ':bay:', 'Пока', 'br'),
(37, ':puk:', 'Взрыв!', 'ck'),
(38, ':med:', 'Медсестра', 'co'),
(39, ':zluka:', 'Закричу!', 'cr'),
(40, ':rab:', 'Работа', 'de'),
(41, ':nak:', 'Наказал', 'dl'),
(42, ':hii:', 'Здрасте)', 'dq'),
(43, ':eee:', 'Есть', 'bx'),
(44, ':game:', 'Играю', 'cc'),
(45, ':idiot:', 'Я идиот', 'ce'),
(46, ':giveheart:', 'Дарю сердце..', 'cv'),
(47, ':tormoz:', 'Я тормоз', 'dd'),
(48, ':korona:', 'Корона', 'di'),
(49, ':P', 'Язык', 'dp'),
(50, ':art:', 'Искуство', 'dt'),
(51, ':sport:', 'Я спортсмен', 'du'),
(52, ':dance:', 'Танцуем все!!!', 'dv'),
(53, ':hi-hi:', 'Хихикаю ^_^', 'ap'),
(54, ':-P', 'Язык', 'ae'),
(55, 'O_O', 'Я в шоке...', 'ai'),
(56, ':stop:', 'Хватит!', 'av'),
(57, ':kiss_you:', 'Целую.', 'aw'),
(58, ':rose:', 'Дарю розу', 'ax'),
(59, ':dont_know:', 'Не знаю', 'bn'),
(60, ':hitr:', 'Не хитри!', 'bt'),
(61, 'x-D', 'РЖУ!', 'ca'),
(62, ':hung:', 'Повесился', 'dc'),
(63, ':mag:', 'Я волшебник!', 'dm'),
(64, ':drink:', 'Пьем', '64'),
(65, ':!lol!:', 'Очень смешно!', 'c22f71bc2573'),
(66, ':close_tema:', 'Тема закрыта', 'close_tema'),
(67, ':flood:', 'Флуд', 'flood'),
(68, ':girl_devil:', 'Девочка дьявол', 'girl_devil'),
(69, ':girl_truce:', 'Лифчик', 'girl_flag_of_truce'),
(70, ':witch:', 'Ведьма', 'girl_witch'),
(71, ':morning:', 'Доброе утро', 'morning1'),
(72, ':grisha:', 'Я ГРИША!', 'my_name_is_grisha'),
(73, ':russian:', 'Россия', 'russian'),
(74, ':vinsent:', 'Банда', 'vinsent'),
(75, ':lol:', 'LOL', 'icon_lol'),
(76, ':narik:', 'Нарик', 'narik'),
(77, ':smoke:', 'Курю', 'smoke'),
(78, ':bomj:', 'Бомж', 'bomj'),
(79, ':kiv:', 'Киваю', 'bs'),
(80, ':beer:', 'Пиво', 'az'),
(81, ':write:', 'Пишу', 'bv'),
(82, ':girl_hi:', 'Здрасте ^^', 'cw'),
(83, ':superman:', 'Супермэн', 'superman'),
(84, ':aikido:', 'Йооооууууааааааа....', 'aikido00'),
(85, ':butcher:', 'Палач', 'butcher0'),
(86, ':download:', 'Качаю', 'download'),
(87, ':dwarf:', 'Викинг', 'dwarf000'),
(88, ':gbanda:', 'Банда!!!', 'gun_band'),
(89, ':jester:', 'Клоун', 'jester00'),
(90, ':present:', 'Скромный подарок', 'present0'),
(91, ':rus_tape:', 'Русская рулетка', 'russian_'),
(92, ':santa:', 'Санта Клаус', 'santa000'),
(93, ':scenario:', 'Сценарий', 'scenic00'),
(94, ':skull:', 'Череп!', 'skull000'),
(95, ':midair:', 'Я взлетаю!', 'fly_smile'),
(96, ':buybuy:', 'Пока, пока', 'smile-08'),
(97, ':zombi:', 'Зомби', 'zombi'),
(98, ':downlol:', 'Ахахаха!!!', 'downlol'),
(99, ':reanimacia:', 'Реанимация', 'i0055'),
(100, ':pioners:', 'Пионеры', 'i0053'),
(101, ':gunner:', 'Стрелок', 'i0049'),
(102, ':smilefly:', 'Ыыы, лечу', 'i0030'),
(103, ':cacheli:', 'Качели', 'i0040'),
(104, ':newyeargift:', 'Подарки на новый год', 'i0069'),
(105, ':newyearel:', 'Елка', 'i0066'),
(106, ':newcrysmile:', 'Грустно на новый год', 'i0071'),
(107, ':russiaflag:', 'Флаг России', '3dflagsdotcom_russi_2faws'),
(108, ':newkepny:', 'Крутой в шапке', '1126965427'),
(109, ':o_O:', 'o_O', 'cp'),
(110, ':woman:', 'Мать', 'fq'),
(111, ':arco:', 'Скрипка', 'fu'),
(112, ':bayan:', 'Баян', 'fx'),
(113, ':telefon:', 'Телефон', 'gy'),
(114, ':pinkicecream:', 'Розовое мороженое', 'hb'),
(115, ':headmusic:', 'Музыка, наушники', 'hc'),
(116, ':plav:', 'Плавец', 'hh'),
(117, ':temperature:', 'Градусник', 'hr'),
(118, ':goldgift:', 'Золотой кубок', 'hs'),
(119, ':musor:', 'Мусорок)', 'ht'),
(120, ':unitaz:', 'Смойся в Унитаз!', 'hu'),
(121, ':sun:', 'Солнышко', 'hy'),
(122, ':-(', 'Печаль', 'icon_sad');

-- --------------------------------------------------------

--
-- Структура таблицы `spam`
--

CREATE TABLE IF NOT EXISTS `spam` (
  `wid` mediumint(9) NOT NULL AUTO_INCREMENT,
  `sword` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`wid`),
  KEY `sword` (`sword`)
) ENGINE=MyISAM  DEFAULT CHARSET=cp1251 COMMENT='Список запрещенных слов' AUTO_INCREMENT=32 ;

--
-- Дамп данных таблицы `spam`
--

INSERT INTO `spam` (`wid`, `sword`) VALUES
(1, 'https://'),
(2, 'www'),
(3, 'http://'),
(4, 'ftp://'),
(5, '.ru'),
(6, '.com'),
(7, '.biz'),
(8, '.info'),
(9, '.org'),
(10, '.su'),
(11, '.net'),
(12, '.php'),
(13, '.html'),
(14, 'porno'),
(15, 'sex'),
(16, 'anal'),
(17, 'секс'),
(18, 'порно'),
(19, 'бля'),
(20, 'сука'),
(21, 'пизд'),
(22, 'прода'),
(23, 'куплю'),
(24, 'ебат'),
(25, 'заебал'),
(26, 'хуй'),
(27, 'ебал'),
(28, 'суки'),
(29, '.рф'),
(30, 'говно'),
(31, 'пидарас');

-- --------------------------------------------------------

--
-- Структура таблицы `stats`
--

CREATE TABLE IF NOT EXISTS `stats` (
  `stid` mediumint(9) NOT NULL AUTO_INCREMENT,
  `sfid` mediumint(9) DEFAULT NULL,
  `viewers` bigint(20) DEFAULT '0',
  `lastview` datetime DEFAULT '2011-07-02 23:11:00',
  `lastip` varchar(16) DEFAULT '127.0.0.1',
  PRIMARY KEY (`stid`),
  UNIQUE KEY `sfid` (`sfid`),
  KEY `viewers` (`viewers`)
) ENGINE=MyISAM  DEFAULT CHARSET=cp1251 COMMENT='Статистика' AUTO_INCREMENT=6 ;

--
-- Дамп данных таблицы `stats`
--

INSERT INTO `stats` (`stid`, `sfid`, `viewers`, `lastview`, `lastip`) VALUES
(1, 2, 1, '2015-09-03 17:59:11', '127.0.0.1'),
(2, 3, 3, '2015-09-03 17:59:14', '127.0.0.1'),
(3, 4, 2, '2015-09-03 17:59:15', '127.0.0.1'),
(4, 5, 2, '2015-09-03 17:59:18', '127.0.0.1'),
(5, 6, 2, '2015-09-03 17:59:19', '127.0.0.1');

-- --------------------------------------------------------

--
-- Структура таблицы `subcategory`
--

CREATE TABLE IF NOT EXISTS `subcategory` (
  `subcatid` mediumint(9) NOT NULL AUTO_INCREMENT,
  `catid` mediumint(9) DEFAULT '1',
  `subcatref` datetime DEFAULT NULL,
  `subcatname` tinytext,
  `subcatdes` tinytext,
  `subcatkeywords` tinytext,
  `subcatfotos` mediumint(9) DEFAULT '0',
  PRIMARY KEY (`subcatid`),
  KEY `catid` (`catid`),
  FULLTEXT KEY `subcatname` (`subcatname`,`subcatdes`,`subcatkeywords`)
) ENGINE=MyISAM  DEFAULT CHARSET=cp1251 COMMENT='Подкатегории' AUTO_INCREMENT=2 ;

--
-- Дамп данных таблицы `subcategory`
--

INSERT INTO `subcategory` (`subcatid`, `catid`, `subcatref`, `subcatname`, `subcatdes`, `subcatkeywords`, `subcatfotos`) VALUES
(1, 1, '2015-09-03 17:59:07', 'Тестовый', 'тестовый подкаталог', 'тест, проба, каталог, рисунок', 12);

-- --------------------------------------------------------

--
-- Структура таблицы `timestat`
--

CREATE TABLE IF NOT EXISTS `timestat` (
  `tsid` mediumint(9) NOT NULL AUTO_INCREMENT,
  `sday` smallint(6) DEFAULT '0',
  `sweek` smallint(6) DEFAULT '0',
  `smonth` smallint(6) DEFAULT '0',
  `sall` mediumint(9) DEFAULT NULL,
  `lastupdateday` datetime DEFAULT NULL,
  `lastupdateweek` datetime DEFAULT NULL,
  `lastupdatemonth` datetime DEFAULT NULL,
  `GB` float(10,3) NOT NULL,
  PRIMARY KEY (`tsid`),
  UNIQUE KEY `lastupdate` (`lastupdateday`,`lastupdateweek`,`lastupdatemonth`)
) ENGINE=MyISAM  DEFAULT CHARSET=cp1251 COMMENT='Статистика день, месяц' AUTO_INCREMENT=2 ;

--
-- Дамп данных таблицы `timestat`
--

INSERT INTO `timestat` (`tsid`, `sday`, `sweek`, `smonth`, `sall`, `lastupdateday`, `lastupdateweek`, `lastupdatemonth`, `GB`) VALUES
(1, 12, 12, 12, 12, '2015-09-03 17:59:07', '2015-09-03 17:59:07', '2015-09-03 17:59:07', 0.005);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
